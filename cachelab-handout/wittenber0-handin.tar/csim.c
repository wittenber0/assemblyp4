#include "cachelab.h"
#include <stdio.h>

int main()
{
	printf("shalom\n");
    printSummary(0, 0, 0);
    return 0;
}
